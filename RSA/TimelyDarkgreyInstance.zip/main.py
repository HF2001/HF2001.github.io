#keys#
public_key = (113, 21721)
private_key = (14401, 21721)
decrypted_message = ""

e = ""
n = ""
d = ""

#starting message#
def rsa():
  print("Would you like to encrypt or decrypt?")
  print("")
  print("type 'e' to encrypt or 'd' to decrypt.")
  answer = input()
  if answer == 'e' or answer == 'E':
    print("")
    print("you chose to encrypt")
    print("")
    e = int(input("enter 'e' value: "))
    n = int(input("enter 'n' value: "))
    encrypt(e, n)

  elif answer == 'd' or answer == 'D':
    print("")
    print("you chose to decrypt")
    print("")
    d = int(input("enter 'd' value: "))
    n = int(input("enter 'n' value: "))
    decrypt(d, n)
  else:
    print("")
    print("answer not found, try again")
    rsa()


  #encryption function#


def encrypt(e, n):
  print("to encrypt please give the following:")  
  print("")
  print("enter the message you would like to encrypt")

  encrypted_message = ""

  answer = input()
  
  for letter in answer:
    numerize = ord(letter)
    encrypt = pow(numerize, e, n)
    denumerize = chr(encrypt)
    encrypted_message += denumerize

  print(encrypted_message)


###decryption funcation###
def decrypt(d, n):

  decrypted_message = ""

  message = input('What would you like to decrypt?\n')
  for t in message:
    numerize = ord(t)
    decrypt = pow(numerize, d, n)
    denumerize = chr(decrypt)
    decrypted_message += denumerize
  print(decrypted_message)
  #########


rsa()